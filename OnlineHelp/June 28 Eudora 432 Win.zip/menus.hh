#define paste_special	57639
